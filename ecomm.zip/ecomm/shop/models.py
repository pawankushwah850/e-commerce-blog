from django.db import models

# Create your models here.

class Product(models.Model):
    pro_id= models.AutoField(primary_key= True)
    pro_name= models.CharField(max_length=55)
    pro_description= models.TextField()
    pro_price= models.IntegerField()
    pro_date= models.DateField()
    pro_img= models.ImageField("shop/images")

    def __str__(self):
        return self.pro_name


