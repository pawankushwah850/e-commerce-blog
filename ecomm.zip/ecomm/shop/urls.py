
from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name="index"),
    path('contact/',views.contact,name="contact"),
    path('productView',views.productView,name="productView"),
    path('search/',views.search,name="search"),
    path('about/',views.about,name="about"),
    path('checkout/',views.checkout,name="checkout"),
]
