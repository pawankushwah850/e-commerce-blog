from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def index(request):
    return render(request,"shop/index.html")

def about(request):
    return HttpResponse("about us")

def search(request):
    return HttpResponse("search ")

def contact(request):
    return HttpResponse("contact")

def checkout(request):
    return HttpResponse("check out")

def productView(request):
    return render(request,"product view")